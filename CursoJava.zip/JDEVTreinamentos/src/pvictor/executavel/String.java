package pvictor.executavel;

public class String {

	public static void main(java.lang.String[] args) {
		java.lang.String nome = "Paulo";
		
		java.lang.String saida = "Meu nome �: ";

		java.lang.String nome12 = "";
	
	}

}
